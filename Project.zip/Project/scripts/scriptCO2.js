var data, options, chart;

// Let op, er is ook een resize-gedeelte in myCode.js
$(window).resize(function(){
	console.log("DrawChart()");
	DrawChart();
});

// Starten met tekenen grafiek.
google.charts.load('current', {'packages':['line']});
google.charts.setOnLoadCallback(RequestData);         
  

// Callback that creates and populates a data table,
// instantiates the line chart, passes in the data and
// draws it.
function RequestData() 
{                
    $.get(  "https://www.rubu.be/iot/co2/co2.php", 
            {numberOfDataPoints : 240}, 
            OnDataReception,
            "json");               
}       

function OnDataReception(returnedData, statusText)
{    
    if(statusText == "success")
    {
        data = new google.visualization.DataTable();
        data.addColumn('datetime', 'Tijdstip');
        data.addColumn('number', 'CO2 (ppm)');
        data.addColumn('number', 'Lichtwaarde');
   
        for(var index = 0; index < returnedData.data.length; index++)
            data.addRow([new Date(returnedData.data[index].time),  
                            parseFloat(returnedData.data[index].co2), 
                            parseFloat(returnedData.data[index].ldr)]);
							
		options = {
	            	chart: {
	                          	title: 'CO2- en lichtwaardes van de afgelopen 4 uur',
	      						subtitle: 'Katholieke Hogeschool Vives, lokaal A118'
		            		},
		    		width: '800',
		    		height: '550',
					legend: {position:'none', alignment: 'end'}
				  };
					  
		chart = new google.charts.Line(document.getElementById('co2LineGraph'));
	
		DrawChart();
    }
} 

function DrawChart()
{
    chart.draw(data, google.charts.Line.convertOptions(options));
}