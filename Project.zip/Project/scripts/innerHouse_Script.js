
// Zie: https://www.eclipse.org/paho/files/jsdoc/index.html
// en: https://www.eclipse.org/paho/index.php?page=clients/js/index.php

const mqttHost = "test.mosquitto.org";
const mqttPort = 8081;
const topic = "Alarm";
const topic2 = "HUE-Lamp";
var client;
var message;


function ScanBadge(pageid){
    
    var clientId = Math.floor(Math.random() * 100001);
    client = new Paho.MQTT.Client(mqttHost, Number(mqttPort), String(clientId));

    client.onMessageArrived = ReadingRFID;

    client.connect({
        onSuccess: onConnected,
        userName: "",
        password: "",
        useSSL: true
    });

}

window.onload = function(){
    var clientId = Math.floor(Math.random() * 100001);
    client = new Paho.MQTT.Client(mqttHost, Number(mqttPort), String(clientId));

    client.onMessageArrived = HUE_Message;

    client.connect({
        onSuccess: onConnected,
        userName: "",
        password: "",
        useSSL: true
    });

    document.querySelector("#btnSendMessage").addEventListener('click', function(){
        console.log("Send message.");
        message = new Paho.MQTT.Message(document.querySelector("#tbxMessage").value);
        message.destinationName = topic2;
        client.send(message);
    });
};

function ReadingRFID(message)
{
    var AlarmID ="610062543266";
    //var WrongID ="975104145710";
    var ChipID = message.payloadString

    console.log(ChipID)

    if(ChipID == AlarmID)
    {
        console.log("exiting house...")
        location.href = "outerHouse.html"
    }
    else{
        window.alert("wrong RFID, try again!")
        //onMessageArrived()
    }
}

function HUE_Message(message)
{
    console.log("Hue_Message", message.payloadString);

}

function onConnected(context)
{
    console.log("onConnected");

    // Abonnement aangaan...
    client.subscribe(topic, 
        {
            onSuccess: onSubscribed
        });

    client.subscribe(topic2, 
        {
            onSuccess: onSubscribed
        });

}

function onSubscribed(context)
{
    console.log("onSubscribed");
}

//Pop up functions
function openPopUp(){
    var iframe = document.getElementById("iframe-hue")

    if(iframe.style.display =="none")
    {
        iframe.style.display ="block"
    }
    else
    {
        iframe.style.display ="none"
    }
}
function openCO2(){
    var iframe = document.getElementById("co2LineGraph")

    if(iframe.style.display =="none")
    {
        iframe.style.display ="block"
        iframe.style.border = "solid purple 5px"
    }
    else
    {
        iframe.style.display ="none"
    }
    
}