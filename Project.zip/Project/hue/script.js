window.addEventListener(('load'), (event) => {

    ///////////////////////////////////////////////////////////////////////////////////////////////////////// status ophalen
    fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1",
        {
            method: 'GET',
        }).then(Response => Response.json()).
        then(Response => {
            document.getElementById('text-veld-1').textContent = JSON.stringify(Response);
        });

    ///////////////////////////////////////////////////////////////////////////////////////////////////////// aan/uit licht
    document.getElementById("schakelaar-1").onclick = () => {

        if (document.getElementById("schakelaar-1").checked == false) {
            console.log("off")
            fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1/state",
                {
                    method: "PUT",
                    body: '{"on":false}'
                }).then((Response) => Response.json()).then((Response) => console.log(Response));
        }
        else {
            console.log("on")
            fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1/state",
                {
                    method: "PUT",
                    body: '{"on":true}'
                }).then((Response) => Response.json()).then((Response) => console.log(Response));
        }
    };
    
     ///////////////////////////////////////////////////////////////////////////////////////////////////////// dimmen
    document.getElementById("range-1").onchange = () => {
        var range = document.getElementById("range-1").value;
        console.log(range);

        fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1/state",
            {
                method: "PUT",
                body: '{"bri":' + range + "}" //'+range+" voor nummer waarden
            }).then((Response) => Response.json()).then((Response) => console.log(Response));
    }
    
     ///////////////////////////////////////////////////////////////////////////////////////////////////////// kleur aanpassen
    document.getElementById("colorwheel-1").onchange = () => {

        var lamp1 = document.getElementById("lamp1")
        var color = document.getElementById("colorwheel-1").value;

        lamp1.style.color = color;

        color = color.replace('#', '0x');
        //normalize rgb colors
        red = (color >> 16) / 255;
        green = ((color >> 8) & 0xff) / 255;
        blue = (color & 0xff) / 255;
        //////////////////////////

        //console.log("from wheel:\n\rred: "+red + "\n\rgreen: "+green+"\n\rblue: "+blue)

        red = red / 255;
        green = green / 255;
        blue = blue / 255;

        //console.log("from wheel /255 :\n\rred: "+red + "\n\rgreen: "+green+"\n\rblue: "+blue)

        var r = red > 0.04045 ? Math.pow(((red + 0.055) / 1.055), 2.4000000953674316) : red / 12.92;
        var g = green > 0.04045 ? Math.pow(((green + 0.055) / 1.055), 2.4000000953674316) : green / 12.92;
        var b = blue > 0.04045 ? Math.pow(((blue + 0.055) / 1.055), 2.4000000953674316) : blue / 12.92;
        var x = r * 0.664511 + g * 0.154324 + b * 0.162028;
        var y = r * 0.283881 + g * 0.668433 + b * 0.047685;
        var z = r * 8.8E-5 + g * 0.07231 + b * 0.986039;
        var xy = [x / (x + y + z), y / (x + y + z)];

        //console.log("RGB for in hue:\n\rred: "+r + "\n\rgreen: "+g+"\n\rblue: "+b)
        //console.log("XYZ for in hue:\n\rX: "+x + "\n\rY: "+y+"\n\rZ: "+z)
        console.log("XY for in hue:\n\rXY : "+xy)

        

        fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1/state",
            {
                method: "PUT",
                body: JSON.stringify({ "xy": xy })
            }).then((Response) => Response.json()).then((Response) => console.log(Response))
    }
    
})
 ///////////////////////////////////////////////////////////////////////////////////////////////////////// status tonen bij aanpassing
window.addEventListener(('change'), (event) => {
    console.log("on every change send data to hue")
    fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/1",
        {
            method: 'GET',


        }).then(Response => Response.json()).
        then(Response => {
            document.getElementById('text-veld-1').textContent = JSON.stringify(Response);
        });

    // fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2",
    //     {
    //         method: 'GET'


    //     }).then(Response => Response.json()).
    //     then(Response => {
    //         document.getElementById('text-veld-2').textContent = JSON.stringify(Response);
    //     });
})

//lamp 2
// window.addEventListener('load',event=>{
//     fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2",
//     {
//         method: 'GET'
//     }).then(Response => Response.json()).
//     then(Response => {
//         document.getElementById('text-veld-2').textContent = JSON.stringify(Response);
//     });
//     document.getElementById("schakelaar-2").onclick = () => {

//         if (document.getElementById("schakelaar-2").checked == false) {
//             fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2/state",
//                 {
//                     method: "PUT",
//                     body: '{"on":false}'
//                 }).then((Response) => Response.json()).then((Response) => console.log(Response));
//         }
//         else {
//             fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2/state",
//                 {
//                     method: "PUT",
//                     body: '{"on":true}'
//                 }).then((Response) => Response.json()).then((Response) => console.log(Response));
//         }
//     };
//     document.getElementById("range-2").onchange = () => {
//         var range = document.getElementById("range-2").value;
//         console.log(range);

//         fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2/state",
//             {
//                 method: "PUT",
//                 body: '{"bri":' + range + "}"
//             }).then((Response) => Response.json()).then((Response) => console.log(Response));
//     }
//     document.getElementById("colorwheel-2").onchange = () => {

//         var color = document.getElementById("colorwheel-2").value;

//         color = color.replace('#', '0x');
//         //normalize rgb colors
//         red = (color >> 16) / 255;
//         green = ((color >> 8) & 0xff) / 255;
//         blue = (color & 0xff) / 255;
//         //////////////////////////


//         red = red / 255;
//         green = green / 255;
//         blue = blue / 255;

//         var r = red > 0.04045 ? Math.pow(((red + 0.055) / 1.055), 2.4000000953674316) : red / 12.92;
//         var g = green > 0.04045 ? Math.pow(((green + 0.055) / 1.055), 2.4000000953674316) : green / 12.92;
//         var b = blue > 0.04045 ? Math.pow(((blue + 0.055) / 1.055), 2.4000000953674316) : blue / 12.92;
//         var x = r * 0.664511 + g * 0.154324 + b * 0.162028;
//         var y = r * 0.283881 + g * 0.668433 + b * 0.047685;
//         var z = r * 8.8E-5 + g * 0.07231 + b * 0.986039;
//         var xy = [x / (x + y + z), y / (x + y + z)];

//         fetch("http://178.119.181.201:49152/api/d8cHvqBsSW9iVf6lLMlisoJj96RfV7VybBRwmD42/lights/2/state",
//             {
//                 method: "PUT",
//                 body: JSON.stringify({ "xy": xy })
//             }).then((Response) => Response.json()).then((Response) => console.log(Response))
//     }
//     ////////////////
// })
