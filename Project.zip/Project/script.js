function ScanBadge(pageid){
    if(pageid ==1){
        location.href = "innerHouse.html"
    }
    if(pageid ==2){
        location.href = "outerHouse.html"
    }
}