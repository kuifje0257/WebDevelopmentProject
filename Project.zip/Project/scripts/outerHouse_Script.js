
// Zie: https://www.eclipse.org/paho/files/jsdoc/index.html
// en: https://www.eclipse.org/paho/index.php?page=clients/js/index.php

const mqttHost = "test.mosquitto.org";
const mqttPort = 8081;
const topic = "Alarm";
var client;
var message;



function ScanBadge(pageid){
    
    var clientId = Math.floor(Math.random() * 100001);
    client = new Paho.MQTT.Client(mqttHost, Number(mqttPort), String(clientId));

    client.onMessageArrived = ReadingRFID;

    client.connect({
        onSuccess: onConnected,
        userName: "",
        password: "",
        useSSL: true
    });


}

function ReadingRFID(message)
{
    var AlarmID ="610062543266";
    //var WrongID ="975104145710";
    var ChipID = message.payloadString

    console.log(ChipID)

    if(ChipID == AlarmID)
    {
        console.log("entering house...")
        location.href = "innerHouse.html"
    }
    else{
        window.alert("wrong RFID, try again!")
        //onMessageArrived()
    }
}

function onConnected(context)
{
    console.log("onConnected");

    // Abonnement aangaan...
    client.subscribe(topic, 
        {
            onSuccess: onSubscribed
        });

}

function onSubscribed(context)
{
    console.log("onSubscribed");
}